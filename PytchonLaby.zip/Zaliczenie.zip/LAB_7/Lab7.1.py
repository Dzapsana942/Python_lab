import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats

# Wczytanie danych z pliku CSV
df = pd.read_csv("TER1705_CREL_20250729142009/TER1705_CREL_20250729142009.csv", sep=";", encoding="utf-8")

# Usunięcie pustych wartości i konwersja kolumny 'Wartosc' na liczby
df = df.dropna(subset=["Wartosc"]).copy()
df["Wartosc"] = pd.to_numeric(df["Wartosc"].str.replace(",", "."), errors="coerce")

# Sprawdzenie podstawowych informacji
print("Liczba wierszy i kolumn:", df.shape)
print("Przykładowe dane:\n", df.head())

# Statystyki opisowe
print("\nStatystyki opisowe dla kolumny 'Wartosc':")
print(df["Wartosc"].describe())

print("\nTypy zmiennych:\n", df.dtypes)
print("\nBraki danych w kolumnach:\n", df.isnull().sum())

# Usunięcie kolumny Unnamed: 10, jeśli zawiera tylko NaN
if "Unnamed: 10" in df.columns and df["Unnamed: 10"].isna().all():
    df.drop(columns=["Unnamed: 10"], inplace=True)

# Macierz korelacji
plt.figure(figsize=(6, 4))
sns.heatmap(df.corr(numeric_only=True), annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Macierz korelacji między zmiennymi liczbowymi")
plt.tight_layout()
plt.show()



# Skośność i kurtoza
print("\nSkośność (skew):", stats.skew(df["Wartosc"].dropna()))
print("Kurtoza (kurtosis):", stats.kurtosis(df["Wartosc"].dropna()))

# Histogram
plt.figure(figsize=(8, 5))
sns.histplot(df["Wartosc"], bins=30, kde=True, color="skyblue", edgecolor="black")
plt.title("Histogram liczby bezrobotnych")
plt.xlabel("Liczba osób")
plt.ylabel("Częstość")
plt.grid(True, linestyle="--", alpha=0.5)
plt.tight_layout()
plt.show()

# Wykrywanie wartości odstających (z-score > 3)
z = stats.zscore(df["Wartosc"])
df["Outlier_zscore"] = abs(z) > 3
outliers_count = df["Outlier_zscore"].sum()
print(f"\nLiczba wykrytych wartości odstających (z-score > 3): {outliers_count}")

# Boxplot
plt.figure(figsize=(8, 4))
sns.boxplot(x=df["Wartosc"], color="lightcoral", fliersize=5)
plt.title("Boxplot liczby bezrobotnych")
plt.xlabel("Liczba osób")
plt.grid(True, axis="x", linestyle="--", alpha=0.5)
plt.tight_layout()
plt.show()

# Zakres lat
print("\nZakres lat w danych:", df["Rok"].unique())

# Trend bezrobocia w czasie
brzeszcze_trend = df.groupby("Rok")["Wartosc"].mean().reset_index()

plt.figure(figsize=(8, 5))
sns.lineplot(data=brzeszcze_trend, x="Rok", y="Wartosc", marker="o", color="teal")
plt.title("Zmiana liczby bezrobotnych w gminie Brzeszcze")
plt.xlabel("Rok")
plt.ylabel("Liczba bezrobotnych (średnia)")
plt.grid(True, linestyle="--", alpha=0.5)
plt.tight_layout()
plt.show()

# Wypisanie nazw kolumn
print("\nDostępne kolumny w danych:")
for col in df.columns:
    print("-", col)
